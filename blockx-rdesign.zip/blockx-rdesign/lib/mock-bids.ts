import { BidsWithUsers } from '@/db/queries/bids';

// Using Base Sepolia token addresses
// USDT: 0x323e78f944A9a1FcF3a10efcC5319DBb0bB6e673 (6 decimals)
// USDC: 0x036CbD53842c5426634e7929541eC2318f3dCF7e (6 decimals)
// WETH: 0x4200000000000000000000000000000000000006 (18 decimals)
// Price is stored with 8 decimals (multiply by 1e8)
// minAmount and maxAmount are stored with token decimals (USDT/USDC: 1e6, WETH: 1e18)

export const mockBids: BidsWithUsers = [
  {
    id: 'mock-1',
    bidHash: '0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef',
    makerAddress: '0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb1',
    fromToken: '0x323e78f944A9a1FcF3a10efcC5319DBb0bB6e673', // USDT
    toToken: '0x0000000000000000000000000000000000000000',
    price: '3.727', // Human-readable price
    minAmount: '10000.00', // Human-readable amount
    maxAmount: '101259.06', // Human-readable amount
    kycLevel: 1,
    expiresAt: BigInt(Date.now() + 86400000),
    status: 'active',
    fiatCurrency: 'AED',
    paymentMethods: null,
    paymentMethodCodes: ['bank_transfer'],
    bidType: 'sell',
    chainId: 84532, // Base Sepolia
    description: 'Fast and reliable USDT seller',
    creator: {
      id: 'user-1',
      username: 'Zentra',
      walletAddress: '0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb1',
      avatarUrl: null,
      kycLevel: 2,
      totalTrades: 47652,
      successfulTrades: 47500
    }
  },
  {
    id: 'mock-2',
    bidHash: '0xabcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890',
    makerAddress: '0x8f3Cf7ad23Cd3CaDbD9735AFf958023239c6A063',
    fromToken: '0x036CbD53842c5426634e7929541eC2318f3dCF7e', // USDC
    toToken: '0x0000000000000000000000000000000000000000',
    price: '3.725',
    minAmount: '5000.00',
    maxAmount: '85420.50',
    kycLevel: 1,
    expiresAt: BigInt(Date.now() + 86400000),
    status: 'active',
    fiatCurrency: 'AED',
    paymentMethods: null,
    paymentMethodCodes: ['bank_transfer'],
    bidType: 'sell',
    chainId: 84532,
    description: 'Trusted USDC trader',
    creator: {
      id: 'user-2',
      username: 'CryptoTrader',
      walletAddress: '0x8f3Cf7ad23Cd3CaDbD9735AFf958023239c6A063',
      avatarUrl: null,
      kycLevel: 2,
      totalTrades: 12340,
      successfulTrades: 12200
    }
  },
  {
    id: 'mock-3',
    bidHash: '0x567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef1234',
    makerAddress: '0x1f9840a85d5aF5bf1D1762F925BDADdC4201F984',
    fromToken: '0x4200000000000000000000000000000000000006', // WETH
    toToken: '0x0000000000000000000000000000000000000000',
    price: '3650.50',
    minAmount: '1.0',
    maxAmount: '25.5',
    kycLevel: 2,
    expiresAt: BigInt(Date.now() + 86400000),
    status: 'active',
    fiatCurrency: 'AED',
    paymentMethods: null,
    paymentMethodCodes: ['bank_transfer'],
    bidType: 'sell',
    chainId: 84532,
    description: 'Premium WETH seller',
    creator: {
      id: 'user-3',
      username: 'BlockchainPro',
      walletAddress: '0x1f9840a85d5aF5bf1D1762F925BDADdC4201F984',
      avatarUrl: null,
      kycLevel: 3,
      totalTrades: 8950,
      successfulTrades: 8900
    }
  },
  {
    id: 'mock-4',
    bidHash: '0x234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef12',
    makerAddress: '0x6B175474E89094C44Da98b954EedeAC495271d0F',
    fromToken: '0x323e78f944A9a1FcF3a10efcC5319DBb0bB6e673', // USDT
    toToken: '0x0000000000000000000000000000000000000000',
    price: '3.720',
    minAmount: '1000.00',
    maxAmount: '50000.00',
    kycLevel: 1,
    expiresAt: BigInt(Date.now() + 86400000),
    status: 'active',
    fiatCurrency: 'AED',
    paymentMethods: null,
    paymentMethodCodes: ['bank_transfer'],
    bidType: 'sell',
    chainId: 84532,
    description: null,
    creator: {
      id: 'user-4',
      username: null,
      walletAddress: '0x6B175474E89094C44Da98b954EedeAC495271d0F',
      avatarUrl: null,
      kycLevel: 1,
      totalTrades: 2450,
      successfulTrades: 2400
    }
  },
  {
    id: 'mock-5',
    bidHash: '0x890abcdef1234567890abcdef1234567890abcdef1234567890abcdef12345678',
    makerAddress: '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48',
    fromToken: '0x036CbD53842c5426634e7929541eC2318f3dCF7e', // USDC
    toToken: '0x0000000000000000000000000000000000000000',
    price: '3.735',
    minAmount: '20000.00',
    maxAmount: '175500.25',
    kycLevel: 2,
    expiresAt: BigInt(Date.now() + 86400000),
    status: 'active',
    fiatCurrency: 'AED',
    paymentMethods: null,
    paymentMethodCodes: ['bank_transfer'],
    bidType: 'sell',
    chainId: 84532,
    description: 'Large volume USDC trader',
    creator: {
      id: 'user-5',
      username: 'DubaiTrader',
      walletAddress: '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48',
      avatarUrl: null,
      kycLevel: 2,
      totalTrades: 15680,
      successfulTrades: 15600
    }
  },
  {
    id: 'mock-6',
    bidHash: '0xcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890ab',
    makerAddress: '0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599',
    fromToken: '0x4200000000000000000000000000000000000006', // WETH
    toToken: '0x0000000000000000000000000000000000000000',
    price: '3655.00',
    minAmount: '0.5',
    maxAmount: '15.75',
    kycLevel: 1,
    expiresAt: BigInt(Date.now() + 86400000),
    status: 'active',
    fiatCurrency: 'AED',
    paymentMethods: null,
    paymentMethodCodes: ['bank_transfer'],
    bidType: 'sell',
    chainId: 84532,
    description: 'Quick WETH exchange',
    creator: {
      id: 'user-6',
      username: 'QuickExchange',
      walletAddress: '0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599',
      avatarUrl: null,
      kycLevel: 1,
      totalTrades: 5230,
      successfulTrades: 5180
    }
  }
];
